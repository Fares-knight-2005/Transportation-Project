#include "Bus.h"

Bus::Bus()
{
    //ctor
}

Bus::~Bus()
{
    //dtor
}
