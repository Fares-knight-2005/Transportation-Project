#include "Parking.h"

Parking::Parking()
{
    //ctor
}

Parking::~Parking()
{
    //dtor
}
