#ifndef PASSENGER_H
#define PASSENGER_H


class Passenger
{
    public:
        Passenger();
        virtual ~Passenger();

    protected:

    private:
};

#endif // PASSENGER_H
