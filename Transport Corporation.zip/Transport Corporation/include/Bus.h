#ifndef BUS_H
#define BUS_H


class Bus
{
    public:
        Bus();
        virtual ~Bus();

    protected:

    private:
};

#endif // BUS_H
