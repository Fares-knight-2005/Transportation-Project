#ifndef PARKING_H
#define PARKING_H


class Parking
{
    public:
        Parking();
        virtual ~Parking();

    protected:

    private:
};

#endif // PARKING_H
